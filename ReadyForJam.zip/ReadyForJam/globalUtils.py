class BasicHtmlAttrs:
    inputFieldAttrs = attrs = {'class': 'registration__item-input'}